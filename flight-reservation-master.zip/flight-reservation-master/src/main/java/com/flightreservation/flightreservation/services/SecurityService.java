package com.flightreservation.flightreservation.services;

public interface SecurityService {
    boolean login(String username,String password);
}
